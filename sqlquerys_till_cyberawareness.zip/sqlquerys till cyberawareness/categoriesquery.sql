INSERT INTO Categories (CategoryName) VALUES ('Att skydda sig mot bedr�gerier');
INSERT INTO Categories (CategoryName) VALUES ('Cybers�kerhet f�r f�retag');
INSERT INTO Categories (CategoryName) VALUES ('Cyberspionage');
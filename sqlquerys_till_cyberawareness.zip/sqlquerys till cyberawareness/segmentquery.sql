INSERT INTO Segments (SegmentName, CategoryId) VALUES ('Del 1', 1);
INSERT INTO Segments (SegmentName, CategoryId) VALUES ('Del 1', 2);
INSERT INTO Segments (SegmentName, CategoryId) VALUES ('Del 1', 3);
